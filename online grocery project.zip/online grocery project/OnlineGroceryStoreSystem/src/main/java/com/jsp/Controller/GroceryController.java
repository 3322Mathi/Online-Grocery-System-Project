package com.jsp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.GroceryComponent.GroceryEntity;
import com.jsp.GroceryDao.GroceryDao;

@Controller
public class GroceryController {
	
	@Autowired
	GroceryDao dao;
	
	//insert
	@RequestMapping("/insert")
	public ModelAndView getadd()
	{
		ModelAndView mv= new ModelAndView();
		mv.addObject("product",new GroceryEntity());
		mv.setViewName("add");
		return mv;
		
	}
	
	
	@RequestMapping("/save")
	@ResponseBody
	public String getproduct(@ModelAttribute GroceryEntity product)
	{
		return dao.getinsert(product);
	}
	
	//search
	@RequestMapping("/search")
	public String getSearch()
	{
		return "productSearch";
	}
	
	@RequestMapping("/find")
	public ModelAndView getFind(@RequestParam String name)
	{
		
		List<GroceryEntity> gro= dao.getProduct(name);
		if(gro!=null)
		{
			ModelAndView mv= new ModelAndView();
			mv.addObject("detail",gro);
			mv.setViewName("display");
			return mv;
		}
		else
		{
			ModelAndView mv= new ModelAndView();
			mv.addObject("message","Not Available A Product");
			mv.setViewName("error");
			return mv;
		}
		
	}
	
	//Display all the product
	@RequestMapping("/detail")
	public ModelAndView getProductAll()
	{
		List<GroceryEntity> product= dao.getDisplayAll();
		if(product!=null)
		{
			ModelAndView mv= new ModelAndView();
			mv.addObject("productList",product);
			mv.setViewName("displayAll");
			return mv;
		}
		else
		{
			ModelAndView mv= new ModelAndView();
			mv.addObject("message","Not found products");
			mv.setViewName("error");
			return mv;
		}
	}
	
	//purchase
	@RequestMapping("/purchase")
	public String getPurchase()
	{
		return "buy";
	}
	
	@RequestMapping("/purchased")
	public ModelAndView finalStage(@RequestParam String name)
	{
		GroceryEntity result= dao.buyproduct(name);
		if(result!=null)
		{
			ModelAndView mv= new ModelAndView();
			mv.addObject("pro",result);
			mv.setViewName("bill");
			return mv;
			
		}
		else
		{
			ModelAndView mv= new ModelAndView();
			mv.addObject("message","Sorry, Product is not found");
			mv.setViewName("error");
			return mv;
		}
	}
	

}
