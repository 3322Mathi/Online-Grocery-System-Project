package com.jsp.GroceryDao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.GroceryComponent.GroceryEntity;

@Repository
public class GroceryDao {
						//data access object for database operation...
	
	//manager
	@Autowired
	EntityManager manager;
	
	//transaction
	@Autowired
	EntityTransaction transaction;
	
	//insertion.
	public String getinsert(Object product)
	{
		transaction.begin();
		manager.persist(product);
		transaction.commit();
		
		return "successfully inserted";
	}
	
	//find a product
	public List<GroceryEntity> getProduct(String name)
	{
		
		Query query= manager.createQuery("select g from GroceryEntity g where g.name= ?1");
		query.setParameter(1,name);
		
		List<GroceryEntity> list= query.getResultList();
		
		if(list!=null)
		{
			return list;
		}
		else
		{
			return null;
		}
	}
	
	//Display All
	public List<GroceryEntity> getDisplayAll()
	{
		Query query= manager.createQuery("select p from GroceryEntity p");
		List<GroceryEntity> list=query.getResultList();
		return list;
	}
	
	//purchase product...
	public GroceryEntity buyproduct(String name)
	{
		List<GroceryEntity> product= getProduct(name);
		GroceryEntity pro= product.get(0);
		int updatedstock= pro.stockQuantity-1;
		
		
		transaction.begin();
		pro.setStockQuantity(updatedstock);
		manager.merge(pro);
		transaction.commit();
		
		return pro;
		
	}
	
	

}
